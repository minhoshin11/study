var i = 10;
for(var i=0; i<5; i++){
    console.log(i);
}
console.log(i);